#include "stdafx.h"
#include "BossStage.h"


BossStage::BossStage()
{
}


BossStage::~BossStage()
{
}

HRESULT BossStage::init()
{
	m_boss = OBJECTPOOL(Boss)->GetObObject();
	m_boss->init();
	m_player = new Player(MAPMANAGER->GetMap(), { 2,2 }, { 30,50 });
	m_player->init();
	m_player->SetXCamMove(false);
	m_player->SetYCamMove(false);
	cloude.x = 250.0f;
	cloude.y = 510.0f;
	CloudeScale.x = 450.0f;
	CloudeScale.y = 300.0f;
	g_ptCam.x = 0;
	g_ptCam.y = 0;
	BossChange = false;
	m_FirstSound = true;
	m_isBossAttack = false;
	m_Stage = RectMakeCenter(WINSIZEX / 2.0f - 150.0f, (WINSIZEY / 2.0f - 110.0f) + (cloude.y - (WINSIZEY / 2.0f - 110.0f)), WINSIZEX - 350.0f, (WINSIZEY / 2.0f + 350.0f) + CloudeScale.y);
	m_player->Setm_Stage(m_Stage);
	m_boss->SetPlayerPos(&m_player->GetRefm_pos());
	m_boss->Setm_Stage(m_Stage);
	return S_OK;
}

void BossStage::release()
{
}

void BossStage::update()
{
	CloudMove += g_ETime / 4.0f;
	if (m_FirstSound)
	{
		if ((!SOUNDMANAGER->isPlaySound("boss"))) SOUNDMANAGER->play("boss");
		MAPMANAGER->MapChange(_T("BossStage.map"));
		m_player->MapChange();
		m_FirstSound = false;
	}

	if (m_boss->GetBossChange(2))
	{
		CloudMove += g_ETime / 3.0f;
		m_player->update();
	}
	m_boss->update();

	/*if (m_boss->BulletColide(m_player->GetRect()))
	{
		UINT Life = m_player->GetPlayerLife();
		Life--;
		if (Life <= 0)
		{
			if ((SOUNDMANAGER->isPlaySound("boss_1p")))SOUNDMANAGER->stop("boss_1p");
			if ((!SOUNDMANAGER->isPlaySound("Menu"))) SOUNDMANAGER->play("Menu");

			SCENEMANAGER->SceneNext("Menu");
		}
		else
		{
			m_player->SetPlayerLife(Life);
		}
	}*/
}

void BossStage::render()
{
	D3DXCOLOR background = D3DXCOLOR(0.0f, 0.0f, 0.0f, 1);
	DeviceContext->ClearRenderTargetView(RTV, (float *)background);

	IMGMANAGER->GetImage("BossBG_1")->Scale(WINSIZEX - 350.0f, WINSIZEY / 2.0f + 100.0f);
	IMGMANAGER->GetImage("BossBG_1")->Position(WINSIZEX / 2.0f - 150.0f, WINSIZEY / 2.0f - 110.0f);
	IMGMANAGER->Render("BossBG_1");

	IMGMANAGER->GetImage("BossBG_2")->Scale(CloudeScale.x, CloudeScale.y);
	IMGMANAGER->GetImage("BossBG_2")->Position(cloude.x, cloude.y);
	IMGMANAGER->LoofRender("BossBG_2", CloudMove, 0.0f);

	m_boss->render();
	m_player->render();

	for (int i = m_player->GetPlayerLife(); i > 0; i--)
	{
		IMGMANAGER->GetImage("playerLife")->Scale(50, 50);
		IMGMANAGER->GetImage("playerLife")->Position(((WINSIZEX / 2.0f - 150.0f) + 50) + (i * 50), 50);
		IMGMANAGER->Render("playerLife");
	}
}
