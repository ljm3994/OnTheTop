#pragma once
#include "Character/Player.h"
#include "Character/Boss.h"

class BossStage : public GameNode
{
	D3DXVECTOR2	cloude;
	D3DXVECTOR2	CloudeScale;
	D3DXVECTOR4	Cloud_WIndows;
	FRECT m_Stage;
	float		CloudMove = 0;
	bool BossChange;
	Boss * m_boss;
	Player * m_player;
	bool m_FirstSound;
	bool m_isBossAttack;
public:
	BossStage();
	~BossStage();
	HRESULT init() override;
	void release() override;
	void update() override;
	void render() override;
};

