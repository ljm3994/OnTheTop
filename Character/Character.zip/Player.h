#pragma once
#include "CharacterManager.h"
class Player : public CharacterManager
{
	bool m_isJump;
	bool m_isBoss;
	bool m_isFall;
	bool m_IsMove;
	float m_JumpPower;
	UINT PlayerLife;
	FRECT m_Stage;
	D3DXVECTOR3 m_Rotate;
	float CamSpeed;
	bool CamMove;
public:
	Player(Map * map, D3DXVECTOR2 pos, D3DXVECTOR2 scale);
	Player();
	~Player() override;
	HRESULT init() override;
	void release() override;
	void update() override;
	void render() override;
	void ImageChange(MOVE_DIR dir);
	MAKEGETSET(bool, m_isBoss);
	MAKEREFGET(D3DXVECTOR2, m_pos);
	MAKEGETSET(FRECT, m_Stage);
	MAKEGETSET(UINT, PlayerLife);
	MAKEGETSET(bool, CamMove);
	MAKEGETSET(bool, m_IsMove);
};

