#include "stdafx.h"
#include "Player.h"

Player::Player(Map* map, D3DXVECTOR2 pos, D3DXVECTOR2 scale)
	:CharacterManager("playerIdle", pos, scale, map)
{
	m_isJump = false;
	m_isBoss = false;
	m_isFall = false;
	m_JumpPower = 0.0f;
	CamSpeed = 90.0f;
	PlayerLife = 3;
	CamMove = false;
	m_IsMove = true;
	m_Rotate = { 0.0f, 0.0f, 0.0f };
}

Player::Player()
{
}

Player::~Player()
{
}

HRESULT Player::init()
{
	return S_OK;
}

void Player::release()
{
}

void Player::update()
{
	if (!m_isJump)
	{
		if (TileCheck(m_map, COLISION_DOWN) != ColisionDir::COLISION_DOWN)
		{
			m_isFall = true;
			m_Gravity.y = 9.8f;
			GravityApply();
		}
		else
		{
			m_Gravity.y = 0.0f;
			m_isFall = false;
		}
	}
	if (m_IsMove)
	{
		if (m_MoveDir != MOVE_UP)
		{
			if (KEYMANAGER->StayKeyDown(VK_LEFT) && (m_pos.x - (m_Scale.x / 2)) > m_Stage.left)
			{
				m_Rotate.y = PI;

				if (m_MoveDir != MOVE_LEFT)
				{
					m_MoveDir = MOVE_LEFT;

				}
			}
			else if (KEYMANAGER->StayKeyDown(VK_RIGHT) && (m_pos.x + (m_Scale.x / 2)) < m_Stage.right + g_ptCam.x)
			{
				m_Rotate.y = 0.0f;

				if (m_MoveDir != MOVE_RIGHT)
				{
					m_MoveDir = MOVE_RIGHT;
				}
			}
			else
			{
				if (m_MoveDir != MOVE_IDLE)
				{
					m_MoveDir = MOVE_IDLE;
				}
			}
		}
		if (KEYMANAGER->isKeyDown(VK_SPACE) && !m_isJump && !m_isFall)
		{
			m_isJump = true;
			m_JumpPower = 132.0f;
			m_Gravity.y = 0.0f;
			m_MoveDir = MOVE_UP;
		}

		
		if (CamMove)
		{
			g_ptCam.x += m_Dir.x * CamSpeed * g_ETime;

			if (g_ptCam.x < 0)
			{
				g_ptCam.x = 0;
			}
		}
	}
	else
	{
		m_MoveDir = MOVE_IDLE;
	}

	if (m_isJump)
	{
		m_Gravity.y += g_ETime;
		m_pos.y += m_JumpPower * g_ETime;
		g_ptCam.y += m_JumpPower * g_ETime;
		m_JumpPower -= m_Gravity.y;

		if (TileCheck(m_map, COLISION_DOWN) == ColisionDir::COLISION_DOWN && m_Gravity.y > 0.2f)
		{
			m_Dir.y = 0.0f;
			m_Gravity.y = 0.0f;
			m_JumpPower = 0.0f;
			m_isJump = false;
			m_MoveDir = MOVE_IDLE;
		}
	}
	Move(m_MoveDir);
	ImageChange(m_MoveDir);
	m_rect->Position(m_pos);
}

void Player::render()
{
	m_CharacterImage->Scale(m_Scale);
	m_CharacterImage->Position(m_pos);
	m_rect->Render();

	switch (m_MoveDir)
	{
	case MOVE_IDLE:
		m_CharacterImage->PlayAnimation(PlayState::ANI_LOOP, true, 0.5f);
		break;
	case MOVE_LEFT:
		m_CharacterImage->PlayAnimation(PlayState::ANI_LOOP, true, 0.2f);
		break;
	case MOVE_RIGHT:
		m_CharacterImage->PlayAnimation(PlayState::ANI_LOOP, true, 0.2f);
		break;
	case MOVE_UP:
		m_CharacterImage->Render();
		break;
	}

}

void Player::ImageChange(MOVE_DIR MoveDir)
{
	switch (m_MoveDir)
	{
	case MOVE_IDLE:
		if (ImgKey != "playerIdle")
		{
			ImgKey = "playerIdle";
		}
		break;
	case MOVE_LEFT:
		if (ImgKey != "playerRunning")
		{
			ImgKey = "playerRunning";
		}
		break;
	case MOVE_RIGHT:
		if (ImgKey != "playerRunning")
		{
			ImgKey = "playerRunning";
		}
		break;
	case MOVE_UP:
		if (m_JumpPower > 130)
		{
			if (ImgKey != "playerJump")
			{
				ImgKey = "playerJump";
				m_CharacterImage->SetCurrentFrameX(0);
			}
		}
		else
		{
			m_CharacterImage->SetCurrentFrameX(1);
		}
		break;
	}
			
	m_CharacterImage = IMGMANAGER->GetImage(ImgKey);
	m_CharacterImage->Rotate(m_Rotate);
}
